const express =require('express');
const connection=require('./Database/DBconfig.js');//exported from seperate file.
require('dotenv').config();
const bodyParser=require("body-parser")

// Create express app
const app=express();
const PORT=process.env.PORT || 3000;

//parse request data 
app.use(bodyParser.urlencoded({extended: false}));

//parse request data json
app.use(bodyParser.json());

//Home Route
app.get("/",(req,res)=>{
    res.send("<h1>Hello There! </h1>")
})

// Route to create db.
app.get("/db-create", (req,res)=>{
    const dbquery="CREATE DATABASE IF NOT EXISTS dbUniversity";

    connection.query(dbquery,(err,result)=>{
        if(err) throw err;
        console.log("Database created successfully",result)
        res.send(result)
    })
    
});

//Route to create table sem
app.get("/table-sem", (req,res)=>{


    //Semester table
    const semester=`CREATE TABLE IF NOT EXISTS tblSemester(
        semID varchar(10) NOT NULL,
        Semester varchar(50) NOT NULL,
        PRIMARY KEY (semID))`

    
        
    connection.query("USE dbUniversity",(err,result)=>{ // "Select Database"
        if(err) throw err;
        connection.query(semester,(err,result)=>{
            if(err) throw err;
            console.log("Semester Table created successfully",result)
            res.send(result);
        });

    });
   
});


//Route to create table subject.
app.get("/table-subject", (req,res)=>{


    //Subject table
    const subjectinfo=`CREATE TABLE IF NOT EXISTS tblSubjectInfo(
        subjectID varchar(10) NOT NULL,
        subjectCode varchar(50) NOT NULL,
        subjectName varchar(50) NOT NULL,
        semId varchar(15) NOT NULL,
        PRIMARY KEY (subjectID))`
    
    connection.query("USE dbUniversity",(err,result)=>{ // "Select Database"
        if(err) throw err;
        connection.query(subjectinfo,(err,result)=>{
            if(err) throw err;
            console.log("SubjectInfo Table created successfully",result)
            res.send(result);
        });

    });
   
});

//Route to create table result.
app.get("/table-result", (req,res)=>{

    //Result table
    const resultinfo=`CREATE TABLE IF NOT EXISTS tblResult(
        resultID varchar(10) NOT NULL,
        Marks varchar(50) NOT NULL,
        subjectId varchar(50) NOT NULL,
        semId varchar(15) NOT NULL,
        PRIMARY KEY (resultID))`

        // SHOW DATABASES => List the available DB from MySql server
        
    connection.query("USE dbUniversity",(err,result)=>{ // "Select Database"
        if(err) throw err;
            connection.query(resultinfo,(err,result)=>{
            if(err) throw err;
            console.log("Result Table created successfully",result)
            res.send(result);
        });
    });
   
});

//Route to insert data in sem
app.post("/insert-sem",(req,res)=>{

    connection.query("USE dbUniversity",(err,result)=>{
        if(err) throw err;
        
        let semid =req.query.semid;
        let semester = req.query.semester;
        let sql ='INSERT INTO tblsemester(semID,Semester) VALUES (?,?)';
        connection.query(sql,[semid, semester],(err,result)=>{
            if(err) throw err;
            console.log('Inserted');
            res.end();
            })

    });
        

});

//Route to insert data in subject
app.post("/insert-subject",(req,res)=>{

    connection.query("USE dbUniversity",(err,result)=>{
        if(err) throw err;
        
        let subjectID =req.query.subjectID
        let subjectCode =req.query.subjectCode
        let subjectName =req.query.subjectName
        let semid =req.query.semid;
       
        let sql ='INSERT INTO tblsubjectinfo (subjectID,subjectCode,subjectName,semId) VALUES (?,?,?,?)';
        connection.query(sql,[subjectID,subjectCode,subjectName,semid],(err,result)=>{
            if(err) throw err;
            console.log('Inserted');
            res.end();
            })

    });
        

});

//Route to insert data in result
app.post("/insert-result",(req,res)=>{

    connection.query("USE dbUniversity",(err,result)=>{
        if(err) throw err;
        
        let resultID =req.query.resultID
        let Marks =req.query.Marks
        let subjectId =req.query.subjectId
        let semId =req.query.semId;
       
        let sql ='INSERT INTO tblresult (resultID,Marks,subjectId,semId) VALUES (?,?,?,?)';
        connection.query(sql,[resultID,Marks,subjectId,semId],(err,result)=>{
            if(err) throw err;
            console.log('Inserted');
            res.end();
            })

    });
        

});


//Route to display semester table
app.get("/display-sem", (req,res)=>{
    const sql=`SELECT * from tblSemester`;
    

    connection.query("USE dbUniversity",(err,result)=>{
        if(err) console.log("Error");
            connection.query(sql,(err,result)=>{
                if(err) 
                console.log("Error");
    
                res.send(result);
            })

    })
    
});

//Route to display semester table by semID
app.get("/display-sem/:id", (req,res)=>{
    const sql=`SELECT * from tblSemester where semID =?`;
    

    connection.query("USE dbUniversity",(err,result)=>{
        if(err) console.log("Error");
            connection.query(sql,[req.params.id],(err,result)=>{
                if(err) 
                console.log("Error");
    
                res.send(result);
            })

    })
    
});

//Route to display subject table
app.get("/display-subject", (req,res)=>{
    const sql=`SELECT * from tblSubjectInfo`;
    

    connection.query("USE dbUniversity",(err,result)=>{
        if(err) console.log("Error");
            connection.query(sql,(err,result)=>{
                if(err) 
                console.log("Error");
    
                res.send(result);
            })

    })
    
});

//Route to display semester table by subjectID
app.get("/display-subject/:id", (req,res)=>{
    const sql=`SELECT * from tblSubjectInfo where subjectID =?`;
    

    connection.query("USE dbUniversity",(err,result)=>{
        if(err) console.log("Error");
            connection.query(sql,[req.params.id],(err,result)=>{
                if(err) 
                console.log("Error");
    
                res.send(result);
            })

    })
    
});

//Route to display result table
app.get("/display-result", (req,res)=>{
    const sql=`SELECT * from tblresult`;
    

    connection.query("USE dbUniversity",(err,result)=>{
        if(err) console.log("Error");
            connection.query(sql,(err,result)=>{
                if(err) 
                console.log("Error");
    
                res.send(result);
            })

    })
    
});

//Route to display semester table by resultID
app.get("/display-result/:id", (req,res)=>{
    const sql=`SELECT * from tblResult where resultID =?`;
    

    connection.query("USE dbUniversity",(err,result)=>{
        if(err) console.log("Error");
            connection.query(sql,[req.params.id],(err,result)=>{
                if(err) 
                console.log("Error");
    
                res.send(result);
            })

    })
    
});
//setup the server port
app.listen(PORT,()=>{
    console.log(`Server is running on port number ${PORT}`)
})